<?php
$token = "[paste your token here]";
$confirmation = "confstring";
